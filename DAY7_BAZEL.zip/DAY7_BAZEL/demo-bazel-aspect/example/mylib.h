#pragma once

 

const char* getName() noexcept;