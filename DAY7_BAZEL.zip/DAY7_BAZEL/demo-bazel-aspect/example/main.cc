#include <iostream>

#include "mylib.h"

 

int main()

{

    std::cout << "Hello! " << getName() << "!" << std::endl;

    return 0;

}