#include "mylib.h"

 

const char* getName() noexcept

{

    return "Bazel";

}

 