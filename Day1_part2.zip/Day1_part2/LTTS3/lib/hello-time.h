#ifndef LIB_HELLO_TIME_H_
#define LIB_HELLO_TIME_H_
void  print_localtime();
#endif