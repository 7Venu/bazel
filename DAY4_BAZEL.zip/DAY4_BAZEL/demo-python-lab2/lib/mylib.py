def getName() -> str:
    return "Bazel"