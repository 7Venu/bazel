from lib.mylib import getName
if __name__ == "__main__":
    print("Hello ", getName())