from lib.mycalc import add

if __name__ == "__main__":
    print("Sum is", add(10,20))