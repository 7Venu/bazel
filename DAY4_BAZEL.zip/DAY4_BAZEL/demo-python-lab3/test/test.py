import unittest
from lib.mycalc import add

class testSum(unittest.TestCase):
    def test_sum(self):
        self.assertEqual(add(10,20),30)

    def test_sum_negative(self):
        self.assertEqual(add(-10,-20),-30)
if __name__== "__main__":
    unittest.main()