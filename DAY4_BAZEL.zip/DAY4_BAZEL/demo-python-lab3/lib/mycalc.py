def add(a,b) ->int :
    return a+b
