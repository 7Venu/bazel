from src import utils

def main():
    result = utils.factorial(5)
    print(f"The result is {result}")

if __name__ == "__main__":
    main()