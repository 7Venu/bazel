#include<iostream>
#include<cstdlib>
int main ()
{
    const char* sharedVariable = std::getenv("MY_VARIABLE");
    if(sharedVariable)
    {
        std::cout<<"Shared Environment Variable is : "<<sharedVariable<<std::endl;
    }else{
        std::cout<<"Shared Variable in Env is not set "<<std::endl;
    }
    return 0;
}