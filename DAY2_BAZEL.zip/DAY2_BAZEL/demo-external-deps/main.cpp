#include<iostream>
#include "absl/strings/str_cat.h"
int main()
{
    std::cout<<" Using ABSIL External Library "<<absl::StrCat("Hello ","LNT !");
    return 0;
}