
#include<iostream>

int main(){

    std::cout << "Hello Custom Rule!";
    return 0;
}