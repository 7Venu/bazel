#include "Greeting.h"
std::string Greeting::getGreetingMessage()
{
    return "Hello Bazel!";
}