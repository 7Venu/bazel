#ifndef TEMPLATE_GREETING_H
#define TEMPLATE_GREETING_H
#include<string>
class Greeting{
    public:
    std::string getGreetingMessage();
};
#endif