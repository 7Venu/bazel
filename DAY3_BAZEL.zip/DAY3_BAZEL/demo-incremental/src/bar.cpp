#include<iostream>
int main()
{
    std::cout<<"Hello Bar!";
    return 0;
}