#include<iostream>
int main()
{
    std::cout<<"Hello baz!";
    return 0;
}