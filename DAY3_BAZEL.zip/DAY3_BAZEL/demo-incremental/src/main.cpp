#include<iostream>
int main()
{
    std::cout<<"Hello Main!";
    return 0;
}