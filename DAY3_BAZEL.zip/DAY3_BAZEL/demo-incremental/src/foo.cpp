#include<iostream>
int main()
{
    std::cout<<"Hello Foo!!";
    return 0;
}