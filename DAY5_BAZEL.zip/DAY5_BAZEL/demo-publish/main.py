import sys

import requests

 

print(sys.version)

print(requests.__version__)